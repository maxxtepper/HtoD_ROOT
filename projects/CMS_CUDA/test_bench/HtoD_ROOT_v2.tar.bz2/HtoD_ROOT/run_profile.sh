./profile_HtoD gtx pinned
./profile_HtoD gtx paged
./profile_HtoD quadro pinned
./profile_HtoD quadro paged
