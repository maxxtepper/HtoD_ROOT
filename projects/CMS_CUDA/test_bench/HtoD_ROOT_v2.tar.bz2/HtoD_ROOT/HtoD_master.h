extern float HtoD(const uint32_t dim, bool pinned);
