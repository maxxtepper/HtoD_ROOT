rm *.so
make clean
