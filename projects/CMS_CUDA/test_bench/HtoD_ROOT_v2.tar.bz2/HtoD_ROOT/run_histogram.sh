./histogram_HtoD gtx pinned
./histogram_HtoD gtx paged
./histogram_HtoD quadro pinned
./histogram_HtoD quadro paged
